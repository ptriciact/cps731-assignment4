package com.example.assignment4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    RecyclerView rView;

    String tasks[];
    String descriptions[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rView = findViewById(R.id.recyclerView);

        tasks = getResources().getStringArray(R.array.amongUsTasks);
        descriptions = getResources().getStringArray(R.array.taskDescription);

        AUAdapter auAdapter = new AUAdapter(this, tasks, descriptions);
        rView.setAdapter(auAdapter);
        rView.setLayoutManager(new LinearLayoutManager(this));
    }
}