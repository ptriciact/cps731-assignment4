package com.example.assignment4;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AUAdapter extends RecyclerView.Adapter<AUAdapter.MyViewHolder>{

    String d1[], d2[], d3[];
    int images[];
    Context context;

    public AUAdapter (Context ct, String tasks[], String descriptions[], String realDescriptions[]){
        context = ct;
        d1 = tasks;
        d2 = descriptions;
        d3 = realDescriptions;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.rows, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.t1.setText(d1[position]);
        holder.t2.setText(d2[position]);

        holder.mainLayout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, buyBeverage.class);
                intent.putExtra("d1", d1[position]);
                intent.putExtra("d2", d3[position]);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return d1.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView t1, t2;
        LinearLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            t1 = itemView.findViewById(R.id.amongUsT);
            t2 = itemView.findViewById(R.id.amongUsD);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}
