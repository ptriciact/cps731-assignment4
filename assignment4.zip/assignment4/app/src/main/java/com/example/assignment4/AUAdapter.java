package com.example.assignment4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AUAdapter extends RecyclerView.Adapter<AUAdapter.MyViewHolder>{

    String d1[], d2[];
    Context context;

    public AUAdapter (Context ct, String tasks[], String descriptions[]){
        context = ct;
        d1 = tasks;
        d2 = descriptions;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.rows, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.t1.setText(d1[position]);
        holder.t2.setText(d2[position]);
    }

    @Override
    public int getItemCount() {
        return d1.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView t1, t2;
        ImageView image1;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            t1 = itemView.findViewById(R.id.amongUsT);
            t2 = itemView.findViewById(R.id.amongUsD);
        }
    }
}
