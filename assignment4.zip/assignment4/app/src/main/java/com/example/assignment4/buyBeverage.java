package com.example.assignment4;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class buyBeverage extends AppCompatActivity {

    TextView t, d;

    String data1, data2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_beverage);

        t = findViewById(R.id.taskName);
        d = findViewById(R.id.taskDescription);

        getData();
        setData();
    }

    private void getData(){
        if(getIntent().hasExtra("d1") && getIntent().hasExtra("d2")) {
        //if(getIntent().hasExtra("d1") && getIntent().hasExtra("d2")) {
            data1 = getIntent().getStringExtra("d1");
            data2 = getIntent().getStringExtra("d2");
        }
        else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setData(){
        t.setText(data1);
        d.setText(data2);
    }
}